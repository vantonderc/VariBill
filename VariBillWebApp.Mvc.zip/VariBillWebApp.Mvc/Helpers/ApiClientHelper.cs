using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using System.Net;
using System.Text;
using System.Text.Json;
using VariBillWebApp.Mvc.Services.Abstractions;
using VariBillWebApp.Mvc.Utils;

namespace VariBillWebApp.Mvc.Helpers;

/// <summary>
/// Authenticated HTTP client that forwards the user's token or falls back to client credentials.
/// </summary>
public class ApiClientHelper : IVariBillApiClient
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ILogger<ApiClientHelper> _logger;
    private readonly APIValidation _apiValidation;

    public ApiClientHelper(
        IHttpClientFactory httpClientFactory,
        IHttpContextAccessor httpContextAccessor,
        ILogger<ApiClientHelper> logger,
        APIValidation apiValidation)
    {
        _httpClientFactory = httpClientFactory;
        _httpContextAccessor = httpContextAccessor;
        _logger = logger;
        _apiValidation = apiValidation;
    }

    private async Task<HttpClient?> CreateAuthenticatedClientAsync(string endpoint)
    {
        var client = _httpClientFactory.CreateClient("VariBillApi");
        var httpContext = _httpContextAccessor.HttpContext;

        // 1. Try to use the signed‑in user's token
        try
        {
            if (httpContext?.User.Identity?.IsAuthenticated == true)
            {
                var token = await httpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(token))
                {
                    client.SetBearerToken(token);
                    _logger.LogDebug("ApiClientHelper: Using user access token for endpoint {Endpoint}", endpoint);
                    return client;
                }
                _logger.LogDebug("ApiClientHelper: No user access token available for endpoint {Endpoint}", endpoint);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ApiClientHelper: Exception while attempting to read user token");
        }

        // 2. Fallback to client credentials
        try
        {
            var tokenResponse = await _apiValidation.CheckServerAsync(client);
            if (tokenResponse?.Success == true && !string.IsNullOrEmpty(tokenResponse.Token))
            {
                client.SetBearerToken(tokenResponse.Token);
                _logger.LogDebug("ApiClientHelper: Using client_credentials token for endpoint {Endpoint}", endpoint);
                return client;
            }
            _logger.LogWarning("ApiClientHelper: client_credentials failed: {Message}", tokenResponse?.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ApiClientHelper: Exception while requesting client_credentials token");
        }

        _logger.LogWarning("ApiClientHelper: Failed to obtain valid API token for endpoint: {Endpoint}", endpoint);
        return null;
    }

    private static StringContent ToJsonContent<T>(T body) =>
        new(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");

    public async Task<HttpResponseMessage> GetAsync(string endpoint)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return new HttpResponseMessage(HttpStatusCode.Unauthorized);
        return await client.GetAsync(endpoint);
    }

    public async Task<TResponse?> GetAsync<TResponse>(string endpoint)
    {
        var response = await GetAsync(endpoint);
        return await DeserializeSuccessResponseAsync<TResponse>(response);
    }

    public async Task<TResponse?> PostAsync<TRequest, TResponse>(string endpoint, TRequest requestBody, string? correlationId = null)
    {
        var response = await PostRawAsync(endpoint, requestBody);
        return await DeserializeSuccessResponseAsync<TResponse>(response);
    }

    public async Task<HttpResponseMessage> PutAsync<TRequest>(string endpoint, TRequest body)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return new HttpResponseMessage(HttpStatusCode.Unauthorized);
        return await client.PutAsync(endpoint, ToJsonContent(body));
    }

    public async Task<HttpResponseMessage> DeleteAsync(string endpoint)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return new HttpResponseMessage(HttpStatusCode.Unauthorized);
        return await client.DeleteAsync(endpoint);
    }

    public async Task<HttpResponseMessage> PostRawAsync<TRequest>(string endpoint, TRequest body)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return new HttpResponseMessage(HttpStatusCode.Unauthorized);
        return await client.PostAsync(endpoint, ToJsonContent(body));
    }

    public async Task<HttpResponseMessage> PostRawAsync(string endpoint, HttpContent content)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return new HttpResponseMessage(HttpStatusCode.Unauthorized);
        return await client.PostAsync(endpoint, content);
    }

    public async Task<TResponse?> PostMultipartAsync<TResponse>(string endpoint, MultipartFormDataContent content)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return default;

        var response = await client.PostAsync(endpoint, content);
        return await DeserializeSuccessResponseAsync<TResponse>(response);
    }

    public async Task<HttpResponseMessage> PostMultipartRawAsync(string endpoint, MultipartFormDataContent content)
    {
        var client = await CreateAuthenticatedClientAsync(endpoint);
        if (client is null)
            return new HttpResponseMessage(HttpStatusCode.Unauthorized);

        return await client.PostAsync(endpoint, content);
    }

    private async Task<TResponse?> DeserializeSuccessResponseAsync<TResponse>(HttpResponseMessage response)
    {
        if (!response.IsSuccessStatusCode)
        {
            var error = await response.Content.ReadAsStringAsync();
            _logger.LogWarning("API call failed. Status: {StatusCode}, Error: {Error}", response.StatusCode, error);
            return default;
        }

        var json = await response.Content.ReadAsStringAsync();
        if (string.IsNullOrWhiteSpace(json))
            return default;

        try
        {
            return JsonSerializer.Deserialize<TResponse>(json, JsonOptions);
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Failed to deserialize API response.");
            throw;
        }
    }
}
