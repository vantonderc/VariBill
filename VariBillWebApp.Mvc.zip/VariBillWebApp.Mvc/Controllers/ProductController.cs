using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using VariBillWebApp.Mvc.Models.ViewModels;
using VariBillWebApp.Mvc.Services.Abstractions;

namespace VariBillWebApp.Mvc.Controllers;

/// <summary>
/// Product CRUD (server-rendered views).
/// </summary>
///
[Route("product")]
[Authorize]
public class ProductController : Controller
{
    private readonly IProductService _productService;
    private readonly IProductTypeService _productTypeService;
    private readonly ILogger<ProductController> _logger;

    public ProductController(
        IProductService productService,
        IProductTypeService productTypeService,
        ILogger<ProductController> logger)
    {
        /// <summary>
        /// Initializes a new instance of <see cref="ProductController"/>.
        /// </summary>
        /// <param name="productService">Service used to manage products.</param>
        /// <param name="productTypeService">Service used to manage product types.</param>
        /// <param name="logger">Logger for the controller.</param>
        _productService = productService;
        _productTypeService = productTypeService;
        _logger = logger;
    }

    [HttpGet("antiforgery/token")]
    public IActionResult GetAntiforgeryToken([FromServices] IAntiforgery antiforgery)
    {
        var tokens = antiforgery.GetAndStoreTokens(HttpContext);
        return Ok(new { token = tokens.RequestToken, headerName = tokens.HeaderName });
    }

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var products = await _productService.GetAllProductsAsync();
        return View(products);
    }

    [HttpGet("create")]
    public async Task<IActionResult> Create()
    {
        var productTypes = await _productTypeService.GetAllProductTypesAsync();
        ViewBag.ProductTypes = new SelectList(productTypes, "Id", "Name");
        return View(new ProductFormViewModel());
    }

    [HttpPost("create")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ProductFormViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var productTypes = await _productTypeService.GetAllProductTypesAsync();
            ViewBag.ProductTypes = new SelectList(productTypes, "Id", "Name");
            return View(model);
        }

        var result = await _productService.CreateProductAsync(model);
        if (result == null)
        {
            ModelState.AddModelError("", "Failed to create product.");
            ViewBag.ProductTypes = await _productTypeService.GetAllProductTypesAsync();
            return View(model);
        }

        TempData["Success"] = $"Product '{model.Name}' created successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("edit/{id:guid}")]
    public async Task<IActionResult> Edit(Guid id)
    {
        var product = await _productService.GetProductByIdAsync(id);
        if (product == null)
        {
            TempData["Error"] = $"Product with ID {id} not found.";
            return RedirectToAction(nameof(Index));
        }

        var model = new ProductEditViewModel
        {
            Id = product.Id,
            Name = product.Name,
            SKU = product.SKU,
            Price = product.Price,
            Quantity = product.Quantity,
            Description = product.Description,
            ProductTypeId = product.ProductTypeId,
            IsActive = product.IsActive
        };
        var productTypes = await _productTypeService.GetAllProductTypesAsync();
        ViewBag.ProductTypes = new SelectList(productTypes, "Id", "Name", product.ProductTypeId);
        return View(model);
    }

    [HttpPost("edit")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(ProductEditViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var productTypes = await _productTypeService.GetAllProductTypesAsync();
            ViewBag.ProductTypes = new SelectList(productTypes, "Id", "Name", model.ProductTypeId);
            return View(model);
        }

        var success = await _productService.UpdateProductAsync(model.Id, model);
        if (!success)
        {
            ModelState.AddModelError("", "Failed to update product.");
            ViewBag.ProductTypes = await _productTypeService.GetAllProductTypesAsync();
            return View(model);
        }

        TempData["Success"] = $"Product '{model.Name}' updated successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("delete/{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var product = await _productService.GetProductByIdAsync(id);
        if (product == null)
        {
            TempData["Error"] = $"Product with ID {id} not found.";
            return RedirectToAction(nameof(Index));
        }
        return View(product);
    }

    [HttpPost("delete/{id:guid}")]
    [ValidateAntiForgeryToken]
    [Authorize(Policy = "RequireAdminRole")]
    public async Task<IActionResult> DeleteConfirmed(Guid id)
    {
        var success = await _productService.DeleteProductAsync(id);
        if (!success)
        {
            TempData["Error"] = $"Failed to delete product with ID {id}.";
            return RedirectToAction(nameof(Index));
        }

        TempData["Success"] = "Product deleted successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("details/{id:guid}")]
    public async Task<IActionResult> Details(Guid id)
    {
        var product = await _productService.GetProductByIdAsync(id);
        if (product == null)
        {
            TempData["Error"] = $"Product with ID {id} not found.";
            return RedirectToAction(nameof(Index));
        }
        return View(product);
    }
}


