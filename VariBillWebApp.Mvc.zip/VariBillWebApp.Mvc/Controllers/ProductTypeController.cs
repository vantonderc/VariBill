using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VariBillWebApp.Mvc.Models.ViewModels;
using VariBillWebApp.Mvc.Services.Abstractions;

namespace VariBillWebApp.Mvc.Controllers;

/// <summary>
/// Product type management (server-rendered views).
/// </summary>
[Route("producttype")]
[Authorize]
public class ProductTypeController : Controller
{
    private readonly IProductTypeService _productTypeService;
    private readonly ILogger<ProductTypeController> _logger;

    public ProductTypeController(
        IProductTypeService productTypeService,
        ILogger<ProductTypeController> logger)
    {
        _productTypeService = productTypeService;
        _logger = logger;
    }

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        _logger.LogDebug("ProductTypeController.Index called by {User}", User?.Identity?.Name ?? "anonymous");
        var types = await _productTypeService.GetAllProductTypesAsync();

        // Map from service model to view model
        var viewModels = types.Select(t => new ProductTypeViewModel
        {
            Id = t.Id,
            Name = t.Name,
            Description = t.Description,
            ProductCount = t.ProductCount,
            IsActive = true // Default for legacy
        }).ToList();

        return View(viewModels);
    }

    [HttpGet("create")]
    public IActionResult Create() => View();

    [HttpPost("create")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateProductTypeModel model)
    {
        _logger.LogDebug("ProductTypeController.Create (POST) called. Model valid: {Valid}", ModelState.IsValid);
        if (!ModelState.IsValid)
            return View(model);

        var result = await _productTypeService.CreateProductTypeAsync(model);
        if (result == null)
        {
            ModelState.AddModelError("", "Failed to create product type.");
            return View(model);
        }

        TempData["Success"] = $"Product type '{model.Name}' created successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("edit/{id:guid}")]
    public async Task<IActionResult> Edit(Guid id)
    {
        _logger.LogDebug("ProductTypeController.Edit (GET) called for id={Id}", id);
        var type = await _productTypeService.GetProductTypeByIdAsync(id);
        if (type == null)
        {
            TempData["Error"] = $"Product type with ID {id} not found.";
            return RedirectToAction(nameof(Index));
        }

        // Map from service model to UpdateProductTypeModel
        var model = new UpdateProductTypeModel
        {
            Id = type.Id,
            Name = type.Name,
            Description = type.Description,
            IsActive = true // Default for legacy
        };
        return View(model);
    }

    [HttpPost("edit/{id:guid}")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Guid id, UpdateProductTypeModel model)
    {
        _logger.LogDebug("ProductTypeController.Edit (POST) called for id={Id}. Model valid: {Valid}", id, ModelState.IsValid);
        if (!ModelState.IsValid)
            return View(model);

        if (id != model.Id)
        {
            TempData["Error"] = "ID mismatch.";
            return RedirectToAction(nameof(Index));
        }

        var success = await _productTypeService.UpdateProductTypeAsync(id, model);
        if (!success)
        {
            ModelState.AddModelError("", "Failed to update product type.");
            return View(model);
        }

        TempData["Success"] = $"Product type '{model.Name}' updated successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("delete/{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        _logger.LogDebug("ProductTypeController.Delete (GET) called for id={Id}", id);
        var type = await _productTypeService.GetProductTypeByIdAsync(id);
        if (type == null)
        {
            TempData["Error"] = $"Product type with ID {id} not found.";
            return RedirectToAction(nameof(Index));
        }

        // Map from service model to ProductTypeViewModel
        var viewModel = new ProductTypeViewModel
        {
            Id = type.Id,
            Name = type.Name,
            Description = type.Description,
            ProductCount = type.ProductCount,
            IsActive = true // Default for legacy
        };

        return View(viewModel);
    }

    [HttpPost("delete/{id:guid}")]
    [ValidateAntiForgeryToken]
    [Authorize(Policy = "RequireAdminRole")]
    public async Task<IActionResult> DeleteConfirmed(Guid id)
    {
        var (success, errorMessage) = await _productTypeService.DeleteProductTypeAsync(id);
        if (!success && errorMessage != null)
        {
            TempData["Error"] = errorMessage;
            return RedirectToAction(nameof(Index));
        }
        if (!success)
        {
            TempData["Error"] = $"Product type with ID {id} not found.";
            return RedirectToAction(nameof(Index));
        }

        TempData["Success"] = "Product type deleted successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("debug-token")]
    public async Task<IActionResult> DebugToken()
    {
        var at = await HttpContext.GetTokenAsync("access_token");
        var roles = User.Claims.Where(c => c.Type == "role").Select(c => c.Value).ToList();
        return Json(new { hasAccessToken = !string.IsNullOrEmpty(at), roles });
    }
}
