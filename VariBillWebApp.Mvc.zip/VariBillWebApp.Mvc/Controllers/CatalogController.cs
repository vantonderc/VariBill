using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Mvc;
using VariBillWebApp.Mvc.Models.ViewModels;
using VariBillWebApp.Mvc.Services.Abstractions;

namespace VariBillWebApp.Mvc.Controllers;

/// <summary>
/// AJAX endpoints used by the frontend JavaScript.
/// </summary>
[Route("catalog")]
[Authorize]
public class CatalogController : Controller
{
    private readonly IProductService _productService;
    private readonly IProductTypeService _productTypeService;
    private readonly ILogger<CatalogController> _logger;

    public CatalogController(
        IProductService productService,
        IProductTypeService productTypeService,
        ILogger<CatalogController> logger)
    {
        _productService = productService;
        _productTypeService = productTypeService;
        _logger = logger;
    }

    [HttpGet("antiforgery/token")]
    public IActionResult GetAntiforgeryToken([FromServices] IAntiforgery antiforgery)
    {
        var tokens = antiforgery.GetAndStoreTokens(HttpContext);
        return Ok(new { token = tokens.RequestToken, headerName = tokens.HeaderName });
    }

    [HttpGet("products")]
    public async Task<IActionResult> GetProducts()
    {
        var products = await _productService.GetAllProductsAsync();
        return Ok(products);
    }

    [HttpGet("products/{id:guid}")]
    public async Task<IActionResult> GetProduct(Guid id)
    {
        var product = await _productService.GetProductByIdAsync(id);
        return product is null ? NotFound() : Ok(product);
    }

    [HttpPost("products")] 
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateProduct([FromBody] ProductFormViewModel model)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var created = await _productService.CreateProductAsync(model);
        return created is null ? BadRequest("Unable to create product.") : Ok(created);
    }

    [HttpPut("products/{id:guid}")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateProduct(Guid id, [FromBody] ProductEditViewModel model)
    {
        if (id != model.Id)
            return BadRequest("ID mismatch");

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var success = await _productService.UpdateProductAsync(id, model);
        return success ? NoContent() : NotFound();
    }

    [HttpDelete("products/{id:guid}")]
    [Authorize(Policy = "RequireAdminRole")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteProduct(Guid id)
    {
        var success = await _productService.DeleteProductAsync(id);
        return success ? NoContent() : NotFound();
    }

    [HttpGet("producttypes")]
    public async Task<IActionResult> GetProductTypes()
    {
        var types = await _productTypeService.GetAllProductTypesAsync();
        return Ok(types);
    }

    [HttpGet("producttypes/{id:guid}")]
    public async Task<IActionResult> GetProductType(Guid id)
    {
        var type = await _productTypeService.GetProductTypeByIdAsync(id);
        return type is null ? NotFound() : Ok(type);
    }

    [HttpPost("producttypes")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateProductType([FromBody] CreateProductTypeModel model)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var created = await _productTypeService.CreateProductTypeAsync(model);
        return created is null ? BadRequest("Unable to create product type.") : Ok(created);
    }

    [HttpPut("producttypes/{id:guid}")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateProductType(Guid id, [FromBody] UpdateProductTypeModel model)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var success = await _productTypeService.UpdateProductTypeAsync(id, model);
        return success ? NoContent() : NotFound();
    }

    [HttpDelete("producttypes/{id:guid}")]
    [Authorize(Policy = "RequireAdminRole")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteProductType(Guid id)
    {
        var (success, errorMessage) = await _productTypeService.DeleteProductTypeAsync(id);
        if (!success && errorMessage != null)
            return Conflict(new { message = errorMessage });
        if (!success)
            return NotFound();
        return NoContent();
    }
}



