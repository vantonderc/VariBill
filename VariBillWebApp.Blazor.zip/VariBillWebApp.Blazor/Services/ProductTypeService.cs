using VariBillWebApp.Blazor.Models.DTOs;
using VariBillWebApp.Blazor.Services.Abstractions;

namespace VariBillWebApp.Blazor.Services;

/// <summary>
/// Product type service implementation.
/// </summary>
public class ProductTypeService : IProductTypeService
{
    private readonly IApiClient _apiClient;
    private const string BaseRoute = "api/producttypes";

    public ProductTypeService(IApiClient apiClient)
    {
        _apiClient = apiClient;
    }

    public async Task<List<ProductTypeApiResponseDto>> GetAllProductTypesAsync()
    {
        try
        {
            var res = await _apiClient.GetAsync<List<ProductTypeApiResponseDto>>(BaseRoute);
            return res ?? new List<ProductTypeApiResponseDto>();
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"ProductTypeService: GetAllProductTypesAsync failed: {ex}");
            return new List<ProductTypeApiResponseDto>();
        }
    }

    public async Task<ProductTypeApiResponseDto?> GetProductTypeByIdAsync(Guid id)
    {
        return await _apiClient.GetAsync<ProductTypeApiResponseDto>($"{BaseRoute}/{id}");
    }

    public async Task<ProductTypeApiResponseDto?> CreateProductTypeAsync(CreateProductTypeDto dto)
    {
        return await _apiClient.PostAsync<CreateProductTypeDto, ProductTypeApiResponseDto>(BaseRoute, dto);
    }

    public async Task<bool> UpdateProductTypeAsync(Guid id, UpdateProductTypeDto dto)
    {
        var response = await _apiClient.PutAsync($"{BaseRoute}/{id}", dto);
        return response.IsSuccessStatusCode;
    }

    public async Task<(bool Success, string? ErrorMessage)> DeleteProductTypeAsync(Guid id)
    {
        var response = await _apiClient.DeleteAsync($"{BaseRoute}/{id}");

        if (response.IsSuccessStatusCode)
            return (true, null);

        if (response.StatusCode == System.Net.HttpStatusCode.Conflict)
        {
            var msg = await response.Content.ReadAsStringAsync();
            return (false, string.IsNullOrWhiteSpace(msg)
                ? "Cannot delete a type that has products."
                : msg);
        }

        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            return (false, null);

        return (false, "Unable to delete the product type.");
    }
}
